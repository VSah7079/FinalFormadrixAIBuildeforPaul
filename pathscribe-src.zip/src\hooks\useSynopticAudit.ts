/**
 * hooks/useSynopticAudit.ts
 * ─────────────────────────────────────────────────────────────────────────────
 * Wraps logEvent() + sendSynopticNotification() into a single hook so
 * TemplateRenderer and SynopticEditor don't need to call both separately.
 *
 * Key responsibilities:
 *   1. Resolves the current user from AuthContext — callers never pass user
 *      manually unless overriding (e.g. action: 'reset_template', user: 'System')
 *   2. Generates the required `detail` string from the event payload —
 *      callers never construct detail themselves
 *   3. Routes to auditAndNotify (log + email) or auditOnly (log only)
 *
 * Drop-in path: src/hooks/useSynopticAudit.ts
 * ─────────────────────────────────────────────────────────────────────────────
 */

import { useCallback } from 'react';
import { logEvent } from '../audit/auditLogger';
import { AuditEvent } from '../types/AuditEvent';
import { sendSynopticNotification } from '../services/synopticNotificationService';
import { useAuth } from '../contexts/AuthContext';

// Callers never supply id, timestamp, or detail — all resolved internally.
// user is optional: hook uses AuthContext by default; pass explicitly to override
// (e.g. user: 'System' for admin reset actions).
// templateName is a UI-only hint used to build richer detail strings.
type AuditInput = Omit<AuditEvent, 'id' | 'timestamp' | 'detail' | 'user'> & {
  user?: string;
  templateName?: string;
};

/**
 * Derives a human-readable detail string from the event payload.
 * Single authoritative place where action codes become readable audit text.
 */
function buildDetail(input: AuditInput, resolvedUser: string): string {
  const actor = input.user ?? resolvedUser;
  const tpl   = input.templateName
    ? `"${input.templateName}"`
    : input.templateId ?? 'template';

  switch (input.action) {
    case 'state_transition':
      return [
        `${tpl} transitioned`,
        input.stateFrom ? `from "${input.stateFrom}"` : null,
        input.stateTo   ? `to "${input.stateTo}"`     : null,
        `by ${actor}`,
        input.note      ? `— "${input.note}"`         : null,
      ].filter(Boolean).join(' ');

    case 'reset_template':
      return `${tpl} reset to draft by ${actor}`;

    case 'set_single_answer':
      return `Question ${input.questionId}: answer set to "${input.newValue}" (was "${input.oldValue ?? 'unanswered'}")`;

    case 'add_multi_answer':
      return `Question ${input.questionId}: "${input.newValue}" added to selection`;

    case 'remove_multi_answer':
      return `Question ${input.questionId}: "${input.newValue}" removed from selection`;

    case 'set_text_answer':
      return `Question ${input.questionId}: text answer updated by ${actor}`;

    case 'add_comment':
      return `Comment added to question ${input.questionId} by ${actor}`;

    case 'ai_generated_synoptic':
      return `AI-generated synoptic report created for ${tpl}`;

    default:
      return `${input.action.replace(/_/g, ' ')} on ${tpl} by ${actor}`;
  }
}

export function useSynopticAudit() {
  const { user } = useAuth();
  const resolvedUser = user?.name ?? 'Unknown User';

  /**
   * auditAndNotify — use for lifecycle transitions and high-stakes events.
   * Writes to the audit log AND sends an email notification.
   */
  const auditAndNotify = useCallback(async (input: AuditInput): Promise<void> => {
    const event: Omit<AuditEvent, 'id' | 'timestamp'> = {
      ...input,
      user:   input.user ?? resolvedUser,
      detail: buildDetail(input, resolvedUser),
    };

    logEvent(event);

    try {
      await sendSynopticNotification(event);
    } catch (err) {
      console.error('[useSynopticAudit] Notification failed silently:', err);
    }
  }, [resolvedUser]);

  /**
   * auditOnly — use for high-frequency editor actions (field edits, answers).
   * Writes to the audit log only. No email sent.
   */
  const auditOnly = useCallback((input: AuditInput): void => {
    logEvent({
      ...input,
      user:   input.user ?? resolvedUser,
      detail: buildDetail(input, resolvedUser),
    });
  }, [resolvedUser]);

  return { auditAndNotify, auditOnly };
}
