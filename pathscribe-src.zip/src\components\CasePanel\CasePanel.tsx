import React from 'react';
import { useCasePreview } from '../../hooks/useCasePreview';
import { CasePreviewDrawer } from './CasePreviewDrawer';
import { useNavigate } from "react-router-dom";

export interface SimilarCase {
  accession: string;
  diagnosis?: string;
  similarity: number;
  matchReason?: string;
}

interface CasePanelProps {
  isOpen: boolean;
  onClose: () => void;
  patientName: string;
  mrn: string;
  patientHistory: string;
  similarCases: SimilarCase[];
  onRefineSearch: () => void;
}

// ── AI star mark — filled Unicode star in PathScribe teal ────────────────────
const AiStar = ({ size = 13 }: { size?: number }) => (
  <span style={{ color: '#0891B2', fontSize: `${size}px`, marginLeft: '5px', verticalAlign: 'middle', lineHeight: 1 }}>★</span>
);

const CasePanel: React.FC<CasePanelProps> = ({
  isOpen,
  onClose,
  patientName,
  mrn,
  patientHistory,
  similarCases,
  onRefineSearch,
}) => {
  const navigate = useNavigate();

  const {
    selectedCase,
    isOpen: drawerOpen,
    openPreview,
    closePreview,
  } = useCasePreview();

  if (!isOpen) return null;

  return (
    <>
      {/* Main panel */}
      <div
        data-capture-hide="true"
        style={{
          position: 'fixed',
          inset: 0,
          background: 'rgba(0,0,0,0.75)',
          backdropFilter: 'blur(6px)',
          zIndex: 20000,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
        }}
        onClick={onClose}
      >
        <div
          onClick={e => e.stopPropagation()}
          style={{
            width: '980px',
            maxHeight: '85vh',
            minHeight: '560px',
            background: '#0b1120',
            borderRadius: '18px',
            overflow: 'hidden',
            display: 'flex',
            flexDirection: 'column',
            boxShadow: '0 24px 60px rgba(0,0,0,0.5)',
            border: '1px solid rgba(148,163,184,0.4)',
          }}
        >
          {/* Header */}
          <div
            style={{
              padding: '20px 28px',
              borderBottom: '1px solid rgba(51,65,85,0.9)',
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              background: 'radial-gradient(circle at top left, rgba(56,189,248,0.18), transparent 55%)',
              flexShrink: 0,
            }}
          >
            <div>
              <div style={{ fontSize: '10px', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.12em', color: '#64748b', marginBottom: '5px' }}>
                Patient History
              </div>
              <div style={{ fontSize: '20px', fontWeight: 700, color: '#e5e7eb' }}>
                {patientName}
                <span style={{ color: '#64748b', fontWeight: 500, fontSize: '15px' }}> · MRN {mrn}</span>
              </div>
            </div>
            <button
              onClick={onClose}
              style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: '22px', color: '#64748b', padding: '4px', borderRadius: '6px', lineHeight: 1 }}
              onMouseEnter={e => { e.currentTarget.style.color = '#94a3b8'; e.currentTarget.style.background = 'rgba(255,255,255,0.06)'; }}
              onMouseLeave={e => { e.currentTarget.style.color = '#64748b'; e.currentTarget.style.background = 'none'; }}
            >✕</button>
          </div>

          {/* Body */}
          <div
            style={{
              display: 'grid',
              gridTemplateColumns: 'minmax(0, 1fr) minmax(0, 1.2fr)',
              flex: 1,
              minHeight: 0,
              overflow: 'hidden',
            }}
          >
            {/* Left: Patient history */}
            <div
              style={{
                padding: '20px 24px',
                borderRight: '1px solid rgba(30,41,59,0.9)',
                background: 'radial-gradient(circle at top, rgba(30,64,175,0.35), transparent 60%), #0d1829',
                overflowY: 'auto',
              }}
            >
              <div style={{ fontSize: '11px', fontWeight: 700, color: '#64748b', textTransform: 'uppercase', letterSpacing: '0.1em', marginBottom: '10px' }}>
                Prior Pathology
              </div>
              <div style={{ fontSize: '13px', color: '#e5e7eb', lineHeight: 1.6, whiteSpace: 'pre-wrap' }}>
                {patientHistory || (
                  <span style={{ color: '#334155', fontStyle: 'italic' }}>No patient history available.</span>
                )}
              </div>
            </div>

            {/* Right: AI Matched Cases */}
            <div
              style={{
                padding: '20px 22px',
                background: 'radial-gradient(circle at top right, rgba(8,47,73,0.9), transparent 60%), #0a1628',
                overflowY: 'auto',
                minHeight: '420px',
              }}
            >
              {/* Section title */}
              <div style={{ display: 'flex', alignItems: 'center', marginBottom: '14px' }}>
                <h3 style={{ fontSize: '16px', fontWeight: 600, color: '#cbd5f5', margin: 0 }}>
                  AI Matched Cases<AiStar size={14} />
                </h3>
                <span style={{ marginLeft: '8px', fontSize: '11px', color: '#475569', fontWeight: 500 }}>
                  {similarCases.length} result{similarCases.length !== 1 ? 's' : ''}
                </span>
              </div>

              {similarCases.length === 0 ? (
                <div style={{ fontSize: '13px', color: '#475569', padding: '24px', borderRadius: '10px', border: '1px dashed rgba(51,65,85,0.8)', textAlign: 'center' }}>
                  No matched cases found for the current context.
                </div>
              ) : (
                similarCases.map((sc) => {
                  const pct = Math.round(sc.similarity * 100);
                  const barColor = pct >= 80 ? '#0ea5e9' : pct >= 60 ? '#0891B2' : '#334155';

                  return (
                    <button
                      key={sc.accession}
                      onClick={() => openPreview(sc)}
                      style={{
                        width: '100%',
                        textAlign: 'left',
                        padding: '12px 14px',
                        marginBottom: '8px',
                        borderRadius: '10px',
                        border: '1px solid rgba(51,65,85,0.9)',
                        background: 'rgba(15,23,42,0.9)',
                        cursor: 'pointer',
                        display: 'flex',
                        flexDirection: 'column',
                        gap: '5px',
                        transition: 'all 0.15s',
                      }}
                      onMouseEnter={e => {
                        e.currentTarget.style.borderColor = '#38bdf8';
                        e.currentTarget.style.background = 'rgba(15,23,42,1)';
                      }}
                      onMouseLeave={e => {
                        e.currentTarget.style.borderColor = 'rgba(51,65,85,0.9)';
                        e.currentTarget.style.background = 'rgba(15,23,42,0.9)';
                      }}
                    >
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                        <span style={{ fontSize: '13px', fontWeight: 600, color: '#e5e7eb' }} data-phi="accession">
                          {sc.accession}
                        </span>
                        <span style={{ fontSize: '12px', color: '#9ca3af' }}>
                          {pct}% match
                        </span>
                      </div>

                      {sc.diagnosis && (
                        <div style={{ fontSize: '12px', color: '#cbd5f5', lineHeight: 1.4 }}>
                          {sc.diagnosis}
                        </div>
                      )}

                      {sc.matchReason && (
                        <div style={{ fontSize: '11px', color: '#94a3b8', fontStyle: 'italic' }}>
                          Matched on: {sc.matchReason}
                        </div>
                      )}

                      <div style={{ height: '4px', background: 'rgba(31,41,55,1)', borderRadius: '999px', overflow: 'hidden', marginTop: '3px' }}>
                        <div style={{ width: `${pct}%`, height: '100%', background: barColor, borderRadius: '999px' }} />
                      </div>
                    </button>
                  );
                })
              )}
            </div>
          </div>

          {/* Footer */}
          <div
            style={{
              padding: '12px 18px',
              borderTop: '1px solid rgba(30,41,59,0.9)',
              display: 'flex',
              justifyContent: 'flex-end',
              background: 'rgba(15,23,42,0.98)',
              flexShrink: 0,
            }}
          >
            <button
              onClick={onRefineSearch}
              style={{
                padding: '7px 16px',
                background: '#0ea5e9',
                color: '#0f172a',
                border: 'none',
                borderRadius: '999px',
                cursor: 'pointer',
                fontWeight: 600,
                fontSize: '13px',
                display: 'flex',
                alignItems: 'center',
                gap: '4px',
                transition: 'all 0.15s',
              }}
              onMouseEnter={e => e.currentTarget.style.background = '#38bdf8'}
              onMouseLeave={e => e.currentTarget.style.background = '#0ea5e9'}
            >
              Refine search <AiStar size={12} />
            </button>
          </div>
        </div>
      </div>

      {/* Preview Drawer */}
      <CasePreviewDrawer
        report={selectedCase}
        isOpen={drawerOpen}
        onClose={closePreview}
        onOpenFull={() => {
          navigate(`/report/${selectedCase?.accession}`);
        }}
      />
    </>
  );
};

export default CasePanel;
