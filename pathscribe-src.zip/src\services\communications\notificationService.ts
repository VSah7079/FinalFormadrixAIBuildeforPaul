/**
 * services/communications/notificationService.ts
 * ─────────────────────────────────────────────────────────────────────────────
 * Generic email dispatcher using EmailJS (client-side, no backend required).
 * Transport-only — no domain knowledge.
 *
 * EmailJS credentials are loaded from env vars:
 *   VITE_EMAILJS_SERVICE_ID
 *   VITE_EMAILJS_TEMPLATE_ID
 *   VITE_EMAILJS_PUBLIC_KEY
 *
 * Template variables expected by the EmailJS template:
 *   {{to_email}}   — recipient address(es), comma-separated
 *   {{cc_email}}   — cc address(es), comma-separated (or empty)
 *   {{subject}}    — email subject line
 *   {{body_html}}  — full HTML body
 * ─────────────────────────────────────────────────────────────────────────────
 */

import emailjs from '@emailjs/browser';
import { EmailPayload } from './types';

const SERVICE_ID  = import.meta.env.VITE_EMAILJS_SERVICE_ID  as string;
const TEMPLATE_ID = import.meta.env.VITE_EMAILJS_TEMPLATE_ID as string;
const PUBLIC_KEY  = import.meta.env.VITE_EMAILJS_PUBLIC_KEY  as string;

/**
 * Dispatches an email via EmailJS.
 * Fire-and-forget safe — logs errors but never throws.
 */
export async function sendEmail(payload: EmailPayload): Promise<void> {
  try {
    if (!SERVICE_ID || !TEMPLATE_ID || !PUBLIC_KEY) {
      console.error('[NotificationService] EmailJS credentials missing — check VITE_EMAILJS_* env vars');
      return;
    }

    if (payload.to.length === 0) {
      console.warn('[NotificationService] No recipients — email skipped');
      return;
    }

    const templateParams = {
      to_email:  payload.to.join(', '),
      cc_email:  (payload.cc ?? []).join(', '),
      subject:   payload.subject,
      body_html: payload.bodyHtml,
    };

    await emailjs.send(SERVICE_ID, TEMPLATE_ID, templateParams, PUBLIC_KEY);

    console.info(`[NotificationService] "${payload.subject}" → ${payload.to.join(', ')}`);
  } catch (err) {
    console.error('[NotificationService] EmailJS send failed:', err);
  }
}
