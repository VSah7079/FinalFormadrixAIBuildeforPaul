/**
 * systemConfig.ts — src/types/systemConfig.ts
 * ─────────────────────────────────────────────────────────────────────────────
 * Pure type definitions and default values for PathScribe system configuration.
 * No React, no side effects — safe to import anywhere.
 *
 * This file is the single source of truth for:
 *   - The SystemConfig shape (what fields exist and their types)
 *   - DEFAULT_SYSTEM_CONFIG (safe baseline values for first run / new fields)
 *
 * The runtime layer (loading, persisting, React context) lives in:
 *   contexts/SystemConfigContext.tsx
 *
 * ─── Changelog ───────────────────────────────────────────────────────────────
 * v1  Initial shape — LIS integration flags, approved fonts
 * v2  Added jurisdiction, terminologyConfig (hosted reference model)
 * ─────────────────────────────────────────────────────────────────────────────
 */

// ─── Jurisdiction ─────────────────────────────────────────────────────────────

/**
 * The institution's operating jurisdiction.
 *
 * Determines which national SNOMED CT release and ICD-10 variant are served,
 * and which licenses apply. Set once at deployment — never changed by end users.
 *
 * Jurisdiction notes:
 *
 *   US      — SNOMED CT US Edition (NLM). ICD-10-CM (NLM/CMS).
 *             License: NLM UMLS registration (free). Covers both systems.
 *
 *   CA      — SNOMED CT Canada Edition (Canada Health Infoway). ICD-10-CA (CIHI).
 *             License: Infoway affiliate (free) + CIHI registration (free).
 *
 *   GB_EW   — SNOMED CT UK Edition (NHS Digital / TRUD). ICD-10 WHO.
 *             License: NHS TRUD registration (free). Covers both systems.
 *
 *   GB_SCT  — SNOMED CT UK Edition + Scottish Extension (NHS Scotland / TRUD).
 *             ICD-10 WHO. Same TRUD registration as GB_EW; Scottish Extension
 *             is included in the TRUD release and requires no separate license.
 *
 *   IE      — SNOMED CT via SNOMED International Affiliate License (commercial fee,
 *             register at snomed.org). ICD-10-AM (HSE Ireland / NCPOH).
 *             NOTE: Ireland is not a SNOMED International member country.
 *             The Affiliate License must be obtained before seeding IE production.
 *             Mock mode works without it during development.
 *
 * ICD-11 and ICD-O are served from WHO sources and require no jurisdiction-
 * specific licensing beyond the standard WHO registration.
 */
export type Jurisdiction = 'US' | 'CA' | 'GB_EW' | 'GB_SCT' | 'IE';

// ─── Jurisdiction display helpers ─────────────────────────────────────────────

/** Human-readable label for each jurisdiction. Used in the admin UI. */
export const JURISDICTION_LABELS: Record<Jurisdiction, string> = {
  US:     'United States',
  CA:     'Canada',
  GB_EW:  'England & Wales (NHS)',
  GB_SCT: 'Scotland (NHS Scotland)',
  IE:     'Republic of Ireland (HSE)',
};

/**
 * Returns the ICD-10 variant name for a given jurisdiction.
 * Used by the seed script and admin UI to label the active ICD-10 release.
 */
export const icd10VariantForJurisdiction = (j: Jurisdiction): string => {
  switch (j) {
    case 'US':     return 'ICD-10-CM';
    case 'CA':     return 'ICD-10-CA';
    case 'GB_EW':  return 'ICD-10 (WHO)';
    case 'GB_SCT': return 'ICD-10 (WHO)';
    case 'IE':     return 'ICD-10-AM';
  }
};

/**
 * Returns the SNOMED CT release name for a given jurisdiction.
 * Used in the admin UI and terminology update tooling.
 */
export const snomedReleaseForJurisdiction = (j: Jurisdiction): string => {
  switch (j) {
    case 'US':     return 'SNOMED CT US Edition (NLM)';
    case 'CA':     return 'SNOMED CT Canada Edition (Infoway)';
    case 'GB_EW':  return 'SNOMED CT UK Edition (NHS Digital)';
    case 'GB_SCT': return 'SNOMED CT UK Edition + Scottish Extension (NHS Scotland)';
    case 'IE':     return 'SNOMED CT (SNOMED International Affiliate License)';
  }
};

/**
 * Returns true if the jurisdiction requires a manually obtained license
 * before seeding production terminology.
 * The seed script checks this and requires --confirm-license for these jurisdictions.
 */
export const requiresManualLicense = (j: Jurisdiction): boolean => j === 'IE';

// ─── Terminology system config ────────────────────────────────────────────────

/**
 * Deployment mode for a single terminology system.
 *
 *   mock      — in-memory seed data (development / demo, no Firestore required)
 *   hosted    — Firestore hosted reference, seeded at deployment (v1 production)
 *   live_api  — proxied external API via Cloud Function (v2, future)
 */
export type TerminologyMode = 'mock' | 'hosted' | 'live_api';

/**
 * Configuration for one terminology system (SNOMED, ICD-10, ICD-11, ICD-O).
 */
export interface TerminologySystemConfig {
  /** Whether this system is enabled for the institution. */
  active:  boolean;

  /**
   * How terminology is served.
   * Defaults to 'mock' so development works with no Firestore dependency.
   * Switch to 'hosted' in staging/production after running seedTerminology.ts.
   */
  mode:    TerminologyMode;

  /**
   * The seeded version string — written by the seed script, displayed in the
   * admin UI and audit log.
   * Examples: "ICD-10-CM 2025", "SNOMED CT UK Edition 2025-04-23", "ICD-O-3.2"
   */
  version?: string;
}

/**
 * Groups configuration for all four terminology systems.
 * Accessed as config.terminologyConfig.snomed etc.
 */
export interface InstitutionTerminologyConfig {
  snomed: TerminologySystemConfig;
  icd10:  TerminologySystemConfig;
  icd11:  TerminologySystemConfig;
  icdo:   TerminologySystemConfig;
}

// ─── Identifier formats ───────────────────────────────────────────────────────

/**
 * Institution-specific identifier format configuration.
 *
 * These patterns drive the smart identifier box on the Search page, which
 * auto-detects whether a typed value is an accession number, MRN, or patient
 * name — routing it to the correct search field without requiring the user
 * to select a field type manually.
 *
 * Patterns are standard JavaScript regex strings (without delimiters).
 * Examples:
 *   Accession:  "^[A-Z]\\d{2}-\\d{4}$"   matches S26-4200
 *   MRN:        "^\\d{6,8}$"              matches 123456
 *
 * The smart box detection order is:
 *   1. Test accessionPattern → route to Accession #
 *   2. Test mrnPattern       → route to MRN / Hospital ID
 *   3. Looks like a name (contains space or comma, mostly alpha) → Patient Name
 *   4. Ambiguous             → search all three fields
 */
export interface IdentifierFormats {
  /** Regex pattern for accession numbers. */
  accessionPattern: string;
  /** Example accession number shown in the UI and used to validate the pattern. */
  accessionExample: string;
  /** Regex pattern for MRN / Hospital ID numbers. */
  mrnPattern:       string;
  /** Example MRN shown in the UI and used to validate the pattern. */
  mrnExample:       string;
}


export interface SystemConfig {
  // ── LIS Integration ────────────────────────────────────────────────────────
  lisIntegrationEnabled:           boolean;
  lisEndpoint:                     string;
  lisOwnsStatuses:                 boolean;
  allowPathScribePostFinalActions: boolean;

  // ── Typography ─────────────────────────────────────────────────────────────
  approvedFonts: string[];

  // ── Jurisdiction ───────────────────────────────────────────────────────────
  /**
   * The institution's operating jurisdiction.
   * Determines SNOMED CT national release, ICD-10 variant, and locale defaults.
   * Set at deployment — not editable by end users.
   * Defaults to 'US' so existing installations are unaffected by this addition.
   */
  jurisdiction: Jurisdiction;

  // ── Identifier Formats ─────────────────────────────────────────────────────
  /**
   * Institution-specific patterns for smart identifier detection on Search.
   * See IdentifierFormats for full documentation.
   */
  identifierFormats: IdentifierFormats;

  // ── Terminology ────────────────────────────────────────────────────────────
  /**
   * Per-system terminology configuration.
   * All systems default to mock mode so development and existing installations
   * work without Firestore until seedTerminology.ts is run.
   */
  terminologyConfig: InstitutionTerminologyConfig;
}

// ─── Defaults ─────────────────────────────────────────────────────────────────

/**
 * DEFAULT_SYSTEM_CONFIG
 * ─────────────────────────────────────────────────────────────────────────────
 * Baseline values used when no persisted config exists (first run) or when
 * a new field is added that isn't yet present in a user's saved config.
 *
 * Defaults are intentionally conservative:
 *   - LIS integration off          → PathScribe works standalone out of the box
 *   - Post-final actions allowed   → pathologist has full capability by default
 *   - Core clinical fonts approved → Arial, Times New Roman, Courier New
 *   - Jurisdiction US              → safe default; overridden at deployment
 *   - All terminology mock mode    → no Firestore dependency until seeded
 *   - ICD-11 off by default        → adoption still in progress in most markets
 */
export const DEFAULT_SYSTEM_CONFIG: SystemConfig = {
  // LIS
  lisIntegrationEnabled:           false,
  lisEndpoint:                     '',
  lisOwnsStatuses:                 true,
  allowPathScribePostFinalActions: true,

  // Typography
  approvedFonts: ['Arial', 'Times New Roman', 'Courier New'],

  // Jurisdiction — defaults to US; overridden at deployment
  jurisdiction: 'US',

  // Identifier formats — defaults match the S26-4200 pattern used in mock data
  identifierFormats: {
    accessionPattern: '^[A-Z]\\d{2}-\\d{4,6}$',
    accessionExample: 'S26-4200',
    mrnPattern:       '^\\d{5,10}$',
    mrnExample:       '123456',
  },

  // Terminology — all mock by default, no Firestore dependency
  terminologyConfig: {
    snomed: { active: true,  mode: 'mock' },
    icd10:  { active: true,  mode: 'mock' },
    icd11:  { active: false, mode: 'mock' },
    icdo:   { active: true,  mode: 'mock' },
  },
};
