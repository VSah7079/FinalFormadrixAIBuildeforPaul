import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";

// Auth + Providers
import { AuthProvider } from "./contexts/AuthContext";
import { SystemConfigProvider } from "./contexts/SystemConfigContext";
import { MessagingProvider } from "./contexts/MessagingContext";
import { SpecimenProvider } from "./contexts/useSpecimens";           // New
import { SubspecialtyProvider } from "./contexts/useSubspecialties"; // New
import { SpecimenDictionaryProvider } from "./components/Config/System/useSpecimenDictionary";

// Core Pages
import Home from "./pages/Home";
import Login from "./Login";
import WorklistPage from "./pages/WorklistPage";
import AuditLogPage from "./pages/AuditLogPage";
import ConfigurationPage from "./pages/ConfigurationPage";
import SearchPage from "./pages/SearchPage";

// Reports
import PatientReportPage from "./components/PatientReportPage/PatientReportPage";
import SynopticReportPage from "./pages/SynopticReportPage";
import FullReportPage from "./pages/FullReportPage";

// Templates (Admin + Pathologist)
import { TemplateRenderer } from "./components/Config/Templates";

// Protocol Editor (Admin)
import ProtocolEditor from "./protocols/ProtocolEditor";

//Synoptic Report Editor (Admin)
import SynopticEditor from "./components/Config/Protocols/SynopticEditor";

// Contribution Dashboard
import ContributionDashboardPage from "./pages/ContributionDashboardPage";

// Protected Route Wrapper
import ProtectedRoute from "./ProtectedRoute";
import AppShell from "./components/AppShell/AppShell";

const App: React.FC = () => {
  return (
    <Router>
      <SystemConfigProvider>
        <AuthProvider>
          <MessagingProvider>
            {/* We wrap the app in our new Clinical Data providers */}
            <SpecimenProvider>
              <SubspecialtyProvider>
                <SpecimenDictionaryProvider>
                  <Routes>
                    {/* Public Route */}
                    <Route path="/login" element={<Login />} />

                    {/* Protected Routes */}
                    <Route element={<ProtectedRoute />}>
                      <Route element={<AppShell />}>
                        <Route path="/" element={<Home />} />
                        <Route path="/worklist" element={<WorklistPage />} />
                        <Route path="/search" element={<SearchPage />} />
                        <Route path="/audit" element={<AuditLogPage />} />
                        <Route path="/configuration" element={<ConfigurationPage />} />
                        <Route path="/contribution" element={<ContributionDashboardPage />} />
                      </Route>

                      {/* Clinical Routes — full-screen, own nav, no AppShell */}
                      <Route path="/case/:caseId/synoptic" element={<SynopticReportPage />} />
                      <Route path="/report/:accession" element={<FullReportPage />} />
                      <Route path="/case/:accession" element={<PatientReportPage />} />

                      {/* Synoptic Report Editor */}
                      <Route path="/template-editor/new"         element={<SynopticEditor />} />
                      <Route path="/template-editor/:templateId" element={<SynopticEditor />} />

                      {/* Admin / Config Routes */}
                      <Route path="/configuration/protocols/:protocolId" element={<ProtocolEditor />} />
                      <Route path="/template-review/:templateId" element={<TemplateRenderer />} />
                    </Route>
                  </Routes>
                </SpecimenDictionaryProvider>
              </SubspecialtyProvider>
            </SpecimenProvider>
          </MessagingProvider>
        </AuthProvider>
      </SystemConfigProvider>
    </Router>
  );
};

export default App;