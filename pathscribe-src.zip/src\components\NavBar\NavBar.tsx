/**
 * components/NavBar/NavBar.tsx
 * ─────────────────────────────────────────────────────────────────────────────
 * Shared navigation bar used by AppShell and SynopticReportPage.
 * Pulls auth + messaging state internally — no prop drilling needed.
 *
 * Props:
 *   onLogoClick     — called when logo is clicked (e.g. navigate('/') or guard('/'))
 *   onLogout        — called when sign out is clicked
 *   onProfileClick  — called when profile/initials is clicked
 *   logoHeight      — optional logo height override (default '38px')
 *   background      — optional nav background override
 *   sticky          — whether to use position:sticky (default true)
 *   dataCaptureHide — whether to add data-capture-hide to user/msg elements
 * ─────────────────────────────────────────────────────────────────────────────
 */

import React from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { useMessaging } from '../../contexts/MessagingContext';
import { EnhancementRequestButton } from '../EnhancementRequest/EnhancementRequestButton';
import { loadEnhancementConfig } from '../../services/enhancementRequestService';

// ─── External Links ───────────────────────────────────────────────────────────

const EXTERNAL_LINKS = [
  { name: 'CAP Cancer Protocols',      url: 'https://www.cap.org/protocols/cancer-protocols-templates' },
  { name: 'WHO Classification of Tumours', url: 'https://tumourclassification.iarc.who.int/' },
  { name: 'PathologyOutlines',         url: 'https://www.pathologyoutlines.com/' },
];

// ─── Props ────────────────────────────────────────────────────────────────────

interface NavBarProps {
  onLogoClick:    () => void;
  onLogout:       () => void;
  onProfileClick: () => void;
  logoHeight?:    string;
  background?:    string;
  sticky?:        boolean;
  dataCaptureHide?: boolean;
}

// ─── Component ────────────────────────────────────────────────────────────────

const NavBar: React.FC<NavBarProps> = ({
  onLogoClick,
  onLogout,
  onProfileClick,
  logoHeight      = '38px',
  background      = 'rgba(15, 23, 42, 0.9)',
  sticky          = true,
  dataCaptureHide = false,
}) => {
  const { user }                                    = useAuth();
  const { unreadCount, hasUrgent, setPortalOpen }   = useMessaging();
  const [linksOpen, setLinksOpen]                   = React.useState(false);
  const qaEnabled                                   = loadEnhancementConfig().qaEnabled;

  const userInitials = user?.name
    ? user.name.split(' ').filter(Boolean).map(w => w[0].toUpperCase()).slice(0, 3).join('')
    : '?';

  const captureAttr = dataCaptureHide ? { 'data-capture-hide': 'true' } : {};

  return (
    <>
      <nav style={{
        padding: '0 40px',
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        background,
        backdropFilter: 'blur(20px)',
        height: '70px',
        borderBottom: '1px solid rgba(255,255,255,0.1)',
        position: sticky ? 'sticky' : 'relative',
        top: 0,
        zIndex: 1000,
        flexShrink: 0,
      }}>

        {/* ── Left: Logo + Enhancement buttons ── */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '20px' }}>
          <img
            src="/pathscribe-logo-dark.svg"
            alt="PathScribe AI"
            style={{ height: logoHeight, cursor: 'pointer' }}
            onClick={onLogoClick}
            title="Go to Dashboard"
          />
          <div style={{ width: '1px', height: '24px', background: 'rgba(255,255,255,0.15)' }} />
          <div title="Enhancement Request"><EnhancementRequestButton /></div>
          {qaEnabled && <div title="QA / Bug Report"><EnhancementRequestButton mode="qa" /></div>}
        </div>

        {/* ── Right: User + Buttons ── */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '18px' }}>

          {/* User Profile */}
          <div
            {...captureAttr}
            onClick={onProfileClick}
            title="Profile & System Info"
            style={{ display: 'flex', alignItems: 'center', gap: '12px', cursor: 'pointer' }}
          >
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              <span style={{ fontSize: '15px', fontWeight: 600, color: '#f1f5f9' }}>
                {user?.name || 'Dr. Sarah Johnson'}
              </span>
              {user?.role === 'pathologist' && (
                <span style={{ fontSize: '11px', color: '#0891B2', fontWeight: 700 }}>MD, FCAP</span>
              )}
            </div>
            <div style={{
              width: '40px', height: '40px', borderRadius: '8px',
              border: '2px solid #0891B2',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              color: '#0891B2', fontWeight: 800,
            }}>
              {userInitials}
            </div>
          </div>

          {/* Messages Button */}
          <div {...captureAttr} style={{ position: 'relative' }}>
            <button
              onClick={() => setPortalOpen(true)}
              title="Messaging Portal"
              className={hasUrgent ? 'urgent-glow' : ''}
              style={{
                width: '42px', height: '42px', borderRadius: '10px',
                background: 'transparent',
                border: hasUrgent ? '2px solid #FF453A' : '2px solid #334155',
                color: hasUrgent ? '#FF453A' : '#f1f5f9',
                cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}
            >
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
              </svg>
            </button>
            {unreadCount > 0 && (
              <div style={{
                position: 'absolute', top: '-6px', right: '-6px',
                background: '#FF3B30', color: 'white',
                fontSize: '11px', borderRadius: '50%',
                width: '18px', height: '18px',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                border: '2px solid #020617',
              }}>
                {unreadCount}
              </div>
            )}
          </div>

          {/* Quick Links Button */}
          <button
            onClick={() => setLinksOpen(true)}
            title="External Resources"
            style={{
              width: '42px', height: '42px', borderRadius: '10px',
              background: 'transparent', border: '2px solid #334155',
              color: '#f1f5f9', cursor: 'pointer',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}
          >
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
              <path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71" />
              <path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71" />
            </svg>
          </button>

          {/* Logout Button */}
          <button
            onClick={onLogout}
            title="Sign Out"
            style={{
              width: '42px', height: '42px', borderRadius: '10px',
              background: 'transparent', border: '2px solid #334155',
              color: '#f1f5f9', cursor: 'pointer',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}
          >
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
              <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" />
              <polyline points="16 17 21 12 16 7" />
              <line x1="21" y1="12" x2="9" y2="12" />
            </svg>
          </button>
        </div>
      </nav>

      {/* ── Quick Links Modal ── */}
      {linksOpen && (
        <div style={{
          position: 'fixed', inset: 0,
          background: 'rgba(0,0,0,0.8)', zIndex: 3000,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>
          <div style={{
            background: '#1C1C1E', width: '400px', borderRadius: '14px',
            padding: '24px', textAlign: 'center', border: '1px solid #333',
          }}>
            <h3 style={{ margin: '0 0 20px 0', color: '#FFF' }}>Pathology Resources</h3>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
              {EXTERNAL_LINKS.map(link => (
                <a
                  key={link.url}
                  href={link.url}
                  target="_blank"
                  rel="noreferrer"
                  style={{
                    background: '#2C2C2E', padding: '12px', borderRadius: '8px',
                    color: '#0891B2', textDecoration: 'none',
                  }}
                >
                  {link.name}
                </a>
              ))}
            </div>
            <button
              onClick={() => setLinksOpen(false)}
              style={{ marginTop: '20px', background: 'none', border: 'none', color: '#FFF', cursor: 'pointer' }}
            >
              Close
            </button>
          </div>
        </div>
      )}

      <style>{`
        .urgent-glow { animation: pulse 2s infinite ease-in-out; }
        @keyframes pulse {
          0%   { box-shadow: 0 0 0 transparent; }
          50%  { box-shadow: 0 0 15px #FF453A; }
          100% { box-shadow: 0 0 0 transparent; }
        }
      `}</style>
    </>
  );
};

export default NavBar;
